<?php

namespace uees;

use Illuminate\Database\Eloquent\Model;

class Perfil extends Model
{
    protected $table ="perfil";

    protected $primarykey ="IdPerfil";
    
}
