<?php

namespace uees;

use Illuminate\Database\Eloquent\Model;

class Perfiles extends Model
{
    //
}
